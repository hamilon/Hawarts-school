package com.hamilton.hogwarts;


import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class HouseList extends AppCompatActivity {

    RecyclerView dataList;
    List<String> titles;
    List<Integer> images;
      List<String>  qualities;
    List<String>  Description;

    HouseAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_houses_list);
           dataList = findViewById(R.id.dataList);

            titles = new ArrayList<>();
            images = new ArrayList<>();
            qualities = new ArrayList<>();
            Description= new ArrayList<>();

        titles.add("GRYFFINDOR");
        titles.add("HUFFLEPUFF");
        titles.add("RAVENCLAW");
        titles.add("SLYTHERIN");

        //populating images arraylist
        images.add(R.drawable.gryffindor);
        images.add(R.drawable.hufflepuff);
        images.add(R.drawable.ravenclaw);
        images.add(R.drawable.slytherin);

        //populating qualities arraylist
        qualities.add("Loyalty,dedication,patience,fair play and hardwork");
        qualities.add("intelligent,determined,cunning,ambitiuos,resourcefull and pridefull");
        qualities.add("Knowledge,creativity,intelligent,wisdom and cleverness");
        qualities.add("loyal,brave,courageous,daring,adverturous,chivalrous");



        //populating Description arraylist
        Description.add("Gryffindor fight for what is right and they are usually the ones at head \n" +
                "\tof the pack when it comes to doing something brave or something that takes nerve");
        Description.add("HufflePuff student are just and true and they believe in doing \n" +
                "\t what is nice.Their main purpose in life is to be kind and generous and to spare\n" +
                "\t peoples feelings");
        Description.add("The smartest and the most clever people can be foung in this house,they \n" +
                "   always strive to do what is wise.Thgey also have a good sence of hu mor and are often quirky.\n" +
                "   they lead through wisdom and they will always use their brains to solve any situation");
        Description.add("Slytherin want to be incharge and they want to be leaders.they\n" +
                "\tbelieve in doing what is necessary,they are the most evil wizard");



            //passing all arrays in HouseAdapter objects

            adapter = new HouseAdapter(this,titles,images, qualities, Description);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
            dataList.setLayoutManager(gridLayoutManager);
            dataList.setAdapter(adapter);













        }
    }
