package com.hamilton.hogwarts;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CharactorsList extends AppCompatActivity {

    RecyclerView dataList;
    List<String> names;
    List<String> Bloodstatus;
    List<String>  Maritalstatus;
    List<String>  Nationality;
    List<String> birthdates;

    List<Integer> images;
    CharactorAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charactors_list);
           dataList = findViewById(R.id.dataList);

        names = new ArrayList<>();
        birthdates = new ArrayList<>();
        Bloodstatus  = new ArrayList<>();
        Maritalstatus = new ArrayList<>();
        Nationality = new ArrayList<>();
        images = new ArrayList<>();






        //adding all Characters names in names arraylist
        names.add("Minerva McGonagall");
        names.add("Bartemius Crouch Senior");
        names.add("Rufus Scrimgeour");
        names.add("Pius Thicknesse");
        names.add("Dololres Umbridge");
        names.add("Cornelius Oswald");

        //adding all Characters images in images arraylist
        images.add(R.drawable.minerva);
        images.add(R.drawable.bartemius);
        images.add(R.drawable.rufus);
        images.add(R.drawable.pius);
        images.add(R.drawable.dorelos);
        images.add(R.drawable.cornelius);


        //adding all Characters birthdates in birthdates arraylist
        birthdates.add("4 October");
        birthdates.add("6 February, 1950");
        birthdates.add("24 Septmber ");
        birthdates.add("Pre-1980");
        birthdates.add("1968");
        birthdates.add("26 August ,1965");


        //adding all Characters Bloodstatus in Bloodstatus arraylist
        Bloodstatus.add("Half-blood");
        Bloodstatus.add("Pure-blood");
        Bloodstatus.add("Half-blood");
        Bloodstatus.add("Pure-blood or Half-blood");
        Bloodstatus.add("Half-blood");
        Bloodstatus.add("Pure-blood or Half-blood");

        //adding all Characters Maritalstatus in Maritalstatus arraylist
        Maritalstatus.add("Widowed");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");

        //adding all Characters Nationality in Nationality arraylist
        Nationality.add("Great Britain");
        Nationality.add("British");
        Nationality.add("British");
        Nationality.add("British");
        Nationality.add("British");
        Nationality.add("Great Britain");



        //passing all arrays in CharactorAdapter objects

            adapter = new CharactorAdapter(this,names,images, Bloodstatus, Maritalstatus,  Nationality, birthdates);

            GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
            dataList.setLayoutManager(gridLayoutManager);
            dataList.setAdapter(adapter);













        }
    }
