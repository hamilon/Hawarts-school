package com.hamilton.hogwarts;


import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class SpellList extends AppCompatActivity {

    RecyclerView dataList;
    List<String> titles;
    List<Integer> images;
    List<String> type;
    List<String> pronunciation;
    List<String> description;
    SpellAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spell_list);
        dataList = findViewById(R.id.dataList);

        titles = new ArrayList<>();
        images = new ArrayList<>();
        type = new ArrayList<>();
        pronunciation = new ArrayList<>();
        description = new ArrayList<>();


        //populating images  titles
        titles.add("Aberto");
        titles.add("Accio");
        titles.add("Aguamenti");
        titles.add("Alohomora");
        titles.add("Animagus");
        titles.add("Anapneo");
        titles.add("Avifors");
        titles.add("Ascendio");
        titles.add("Avenseguim");
        titles.add("Avis");
        titles.add("Avifors");
        titles.add("Appare Vestigium");
        titles.add("Arania Exumai");
        titles.add("Arresto Momentum");
        titles.add("Aqua Eructo");
        titles.add("Avada Kedavra");


        //populating images arraylist
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);
        images.add(R.drawable.spell);



        //populating type arraylist
        type.add("Charm");
        type.add("Charm");
        type.add("Charm");
        type.add("Charm");
        type.add("Transfiguration");
        type.add("Healing Spell, Vanishment");
        type.add("Charm");
        type.add("Charm");
        type.add("Charm");
        type.add("Charm");
        type.add("Transfiguration");
        type.add("Charm");
        type.add("Charm");
        type.add("Charm");
        type.add("Charm");
        type.add("Curse");


        //populating  pronunciation arraylist
        pronunciation.add("Ah-bare-toh");
        pronunciation.add("AK-ee-oh");
        pronunciation.add("AH-gwah-MEN-tee");
        pronunciation.add("ah-LOH-ho-MOR-ah");
        pronunciation.add("ah-MAH-toh ah-NEE-moh ah-nee-MAH-toh an-a-MAY-jus ");
        pronunciation.add("ah-NAP-nee-oh");
        pronunciation.add("AH-vi-fors");
        pronunciation.add("ah-SEN-dee-oh");
        pronunciation.add("ah-ven-SEH-gwim ");
        pronunciation.add("AH-gwah-MEN-tee");
        pronunciation.add("AH-vi-fors");
        pronunciation.add("ah-PAR-ay ves-TEE-jee-um");
        pronunciation.add("ah-RAHN-ee-a EKS-su-may");
        pronunciation.add("ah-REST-oh mo-MEN-tum");
        pronunciation.add("A-kwa ee-RUCK-toh");
        pronunciation.add("ah-VAH-dah keh-DAV-rah");


        //populating  description arraylist
        description.add("A spell used to open doors");
        description.add("Summons an object towards the caster");
        description.add("Produces a clean, drinkable jet of water from the wand tip");
        description.add("Unlocks doors and other objects. It can also unlock doors that have been");
        description.add("Spell used as part of the process of becoming an Animagus");
        description.add("Clears the target's airway if they are choking on something");
        description.add("Transforms the target into a bird.");
        description.add("Lifts the caster high into the air. The charm also works underwater,\n" +
                "\t propelling the caster above the surface");
        description.add("Turns an object into a tracking device");
        description.add("Conjures a flock of birds from the tip of the wand. When used in \n"  +
                "\t conjunction with Oppugno, it can be used offensively.");
        description.add("Transforms the target into a bird.");
        description.add("Reveals traces of magic, including footprints and track marks.");
        description.add("Drives away spiders, including Acromantulas");
        description.add("Decreases the velocity of a moving target. Can be used on multiple targets, \n"+
                     "\t as well as on the caster themselves.");
        description.add("This spell is used to create, and control, a jet of clear water from the tip \n" +
                "\t of the wand; it is probably related to Aguamenti");
        description.add("Causes instantaneous death. It is accompanied by a flash of green light \n" +
                "\t and a rushing noise.");



        //passing all arrays in SpellAdapter objects
        adapter = new SpellAdapter(this,titles,images,type,pronunciation,description);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
        dataList.setLayoutManager(gridLayoutManager);
        dataList.setAdapter(adapter);













    }
}
