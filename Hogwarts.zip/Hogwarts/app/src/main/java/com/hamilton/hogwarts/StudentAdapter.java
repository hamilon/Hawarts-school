package com.hamilton.hogwarts;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.ViewHolder> {
    private Activity context;
    List<String> names;
    List<Integer> images;
    LayoutInflater inflater;
    List<String> Bloodstatus;
    List<String>  Maritalstatus;
    List<String>  Nationality;
    List<String> birthdates;

    private Activity activity;
    public StudentAdapter(Context ctx, List<String> names, List<Integer> images,List<String> Bloodstatus,List<String>  Maritalstatus,List<String>  Nationality,List<String> birthdates) {
        this.names = names;
        this.images = images;
        this.Bloodstatus = Bloodstatus;
        this.Maritalstatus=  Maritalstatus;
        this.Nationality = Nationality;
        this.birthdates = birthdates;
        this.inflater = LayoutInflater.from(ctx);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.custom_student_layout, parent, false);
        return new ViewHolder(view);
    }
    //initialising all the variables to be used in diplaying full details of the selected item
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(names.get(position));
        holder.gridIcon.setImageResource(images.get(position));
        holder.nationality=(Nationality.get(position));
        holder.Bloodstatus=(Bloodstatus.get(position));
        holder.Maritalstatus=(Maritalstatus.get(position));
        holder.birthdates=(birthdates.get(position));
        holder.gridIcon.setImageResource(images.get(position));
    }

    @Override
    public int getItemCount() {
        return names.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ImageView gridIcon;
        String nationality;
        String Bloodstatus;
        String  Maritalstatus;
        String birthdates;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textView2);
            gridIcon = itemView.findViewById(R.id.imageView2);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String name =  title.getText().toString();

                    //displaying all detail of selected item from the list

                    Toast.makeText(v.getContext(), "Name : "+name +","+"Birth date:  "+birthdates+","+"Blood status : "+Bloodstatus +", "+"Nationality : "+nationality+", "+"Marital status : "+Maritalstatus, Toast.LENGTH_LONG).show();


                }
            });
        }
    }
}