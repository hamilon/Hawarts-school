package com.hamilton.hogwarts;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btn_Charactor = findViewById(R.id.btn_selCharactors);
        Button btn_House = findViewById(R.id.btn_selHouse);
        Button   btn_Student = findViewById(R.id.btn_selStudent);
        Button  btn_Spell = findViewById(R.id.btn_selSpell);


        //navigating to Charactoer list

        btn_Charactor.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startActivity(new Intent("com.hamilton.hogwarts.CharactorsList"));

            }
        });

        //navigating to House list
        btn_House.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                startActivity(new Intent("com.hamilton.hogwarts.HouseList"));

            }
        });

      //navigating to Student list
        btn_Student.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startActivity(new Intent("com.hamilton.hogwarts.StudentList"));
            }
        });

        //navigating to Spell list
        btn_Spell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              startActivity(new Intent("com.hamilton.hogwarts.SpellList"));

            }
        });






    }

}

