package com.hamilton.hogwarts;


import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class StudentList extends AppCompatActivity {

    RecyclerView dataList;
    List<String> names;
    List<Integer> images;
    List<String> Bloodstatus;
    List<String>  Maritalstatus;
    List<String>  Nationality;
    List<String> birthdates;
    CharactorAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_students_list);
        dataList = findViewById(R.id.dataList);
        names = new ArrayList<>();
        images = new ArrayList<>();
        birthdates = new ArrayList<>();
        Bloodstatus  = new ArrayList<>();
        Maritalstatus = new ArrayList<>();
        Nationality = new ArrayList<>();


        //populating   names arraylist
        names.add("Harry James Potter");
        names.add("Neville Longbottom");
        names.add("Hermione Jean Granger");
        names.add("Ginevra Molly Potter");
        names.add("Filius     Flitwick");
        names.add("Ronald Weasley");

        //populating  Nationality arraylist
        Nationality.add("English");
        Nationality.add("Great Britain");
        Nationality.add("English");
        Nationality.add("British");
        Nationality.add("Great Britain or Ireland");
        Nationality.add("English");


        //populating  Maritalstatus arraylist
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");
        Maritalstatus.add("Married");


        //populating  birthdates arraylist

        birthdates.add("July 31, 1980");
        birthdates.add("30 July, 1980");
        birthdates.add("19 September, 1979 ");
        birthdates.add("13 February, 1981");
        birthdates.add("17 October, 1958");
        birthdates.add("1 March, 1980");


       //populating  Bloodstatus arraylist
        Bloodstatus.add("Half-blood");
        Bloodstatus.add("Pure-blood");
        Bloodstatus.add("Muggle-born");
        Bloodstatus.add("Pure-blood or Half-blood");
        Bloodstatus.add("Part-Goblin");
        Bloodstatus.add("Pure-blood");

        //populating  images arraylist
        images.add(R.drawable.harry);
        images.add(R.drawable.nev);
        images.add(R.drawable.hermi);
        images.add(R.drawable.ginny);
        images.add(R.drawable.filius);
        images.add(R.drawable.ron);




        //passing all arrays in CharactorAdapter objects
        adapter = new CharactorAdapter(this,names,images, Bloodstatus,  Maritalstatus,  Nationality, birthdates);

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
        dataList.setLayoutManager(gridLayoutManager);
        dataList.setAdapter(adapter);













    }
}
